package it.clariter.model.ristorante;

public class Ristorante 
{

	public static void main(String[] args) 
	{
		PiattoMain piattoMain = new PiattoMain();

		
	}
}
